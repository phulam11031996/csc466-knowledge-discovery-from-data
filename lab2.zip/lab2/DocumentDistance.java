public interface DocumentDistance {

    public double findDistance(TextVector query, TextVector document, DocumentCollection documents);

}
