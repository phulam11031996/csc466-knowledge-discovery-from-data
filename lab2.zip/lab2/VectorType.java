enum VectorType {
    DOCUMENT, QUERY
}
